# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class LOStudentTable(Component):
    """A LOStudentTable component.


Keyword arguments:

- cards (list; required):
    Array of cards to display in the list.

- controlGroups (list of dicts; required):
    Array of control groups to display.

    `controlGroups` is a list of dicts with keys:

    - id (string; required)

    - options (list of strings; required)

    - title (string; required)"""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'LOStudentTable'
    @_explicitize_args
    def __init__(self, cards=Component.REQUIRED, controlGroups=Component.REQUIRED, **kwargs):
        self._prop_names = ['cards', 'controlGroups']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['cards', 'controlGroups']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['cards', 'controlGroups']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(LOStudentTable, self).__init__(**args)

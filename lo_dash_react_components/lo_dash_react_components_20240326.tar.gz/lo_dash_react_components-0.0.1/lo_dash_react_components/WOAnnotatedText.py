# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class WOAnnotatedText(Component):
    """A WOAnnotatedText component.
WOAnnotatedText

Keyword arguments:

- id (string; default ''):
    The ID used to identify this component in Dash callbacks.

- breakpoints (list of dicts; optional):
    The breakpoints of our text.

    `breakpoints` is a list of dicts with keys:

    - id (string; optional)

    - offset (number; optional)

    - start (number; optional)

    - style (dict; optional)

    - tooltip (a list of or a singular dash component, string or number; optional)

- className (string; default ''):
    Classes for the outer most div.

- text (string; default ''):
    Text of essay."""
    _children_props = ['breakpoints[].tooltip']
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'WOAnnotatedText'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, breakpoints=Component.UNDEFINED, text=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'breakpoints', 'className', 'text']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'breakpoints', 'className', 'text']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(WOAnnotatedText, self).__init__(**args)

# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class ZPDPlot(Component):
    """A ZPDPlot component.
This is a component which shows which zones different problems fall into for a given student.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- ZPDItemCards (list of dicts; required):
    Data for cards for the items students worked through.

    `ZPDItemCards` is a list of dicts with keys:

    - attempts (string; optional)

    - id (string; optional)

    - itemName (string; optional)

    - supports (string; optional)

    - visited (boolean; optional)

    - zone (string; optional)

- selectedStudent (string; optional):
    The current student for whom we're showing data.

- students (list of strings; optional):
    A list of all available students. This is so we can select a
    student. This should be moved out of this, one level up, so the
    logic is common to any per-student view."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'ZPDPlot'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, students=Component.UNDEFINED, ZPDItemCards=Component.REQUIRED, selectedStudent=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'ZPDItemCards', 'selectedStudent', 'students']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'ZPDItemCards', 'selectedStudent', 'students']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['ZPDItemCards']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(ZPDPlot, self).__init__(**args)

# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class WOStudentTextTile(Component):
    """A WOStudentTextTile component.
WOStudentTextTile

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- childComponent (a list of or a singular dash component, string or number; optional):
    Component to use for within the card body.

- className (string; default ''):
    Classes for the outer most div.

- currentOptionHash (string; optional):
    Hash of the current options, used to determine if we should be in
    a loading state or not.

- selectedDocument (string; optional):
    Which document is currently selected for this student.

- showHeader (boolean; default True):
    Determine whether the header with the student name should be
    visible or not.

- studentInfo (dict; default {  profile: {},  availableDocuments: [],  documents: {}}):
    The breakpoints of our text.

    `studentInfo` is a dict with keys:

    - profile (dict; optional)

    - availableDocuments (list of dicts; optional)

        `availableDocuments` is a list of dicts with keys:

        - id (string; optional)

        - title (string; optional)

    - documents (dict; optional)

- style (dict; optional):
    Style to apply to the outer most item. This is usually used to set
    the size of the tile."""
    _children_props = ['childComponent']
    _base_nodes = ['childComponent', 'children']
    _namespace = 'lo_dash_react_components'
    _type = 'WOStudentTextTile'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, style=Component.UNDEFINED, showHeader=Component.UNDEFINED, selectedDocument=Component.UNDEFINED, currentOptionHash=Component.UNDEFINED, childComponent=Component.UNDEFINED, studentInfo=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'childComponent', 'className', 'currentOptionHash', 'selectedDocument', 'showHeader', 'studentInfo', 'style']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'childComponent', 'className', 'currentOptionHash', 'selectedDocument', 'showHeader', 'studentInfo', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(WOStudentTextTile, self).__init__(**args)

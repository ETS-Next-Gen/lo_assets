# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class helperlib(Component):
    """A helperlib component.
Arrow: A component that represents an arrow between two targets. It is
currently for internal use only.

Keyword arguments:

- source (string; required):
    source: The ID of the source element.

- sourceOffset (list of numbers; optional):
    Where on the source we point to. Typically,
    TOP/LEFT/CENTER/BOTTOM/RIGHT, but can be an array with a length
    (0-1) and an angle (in degrees).

- target (string; required):
    target: The ID of the target element.

- targetOffset (list of numbers; optional):
    Where on the target we point to. Typically,
    TOP/LEFT/CENTER/BOTTOM/RIGHT, but can be an array with a length
    (0-1) and an angle (in degrees).

- wrapper (string; optional):
    wrapper: The ID of any containing element. Obsolete. Should be
    removed."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'helperlib'
    @_explicitize_args
    def __init__(self, source=Component.REQUIRED, target=Component.REQUIRED, wrapper=Component.UNDEFINED, sourceOffset=Component.UNDEFINED, targetOffset=Component.UNDEFINED, **kwargs):
        self._prop_names = ['source', 'sourceOffset', 'target', 'targetOffset', 'wrapper']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['source', 'sourceOffset', 'target', 'targetOffset', 'wrapper']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['source', 'target']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(helperlib, self).__init__(**args)

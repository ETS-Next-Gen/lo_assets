# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class WOStudentTextTile(Component):
    """A WOStudentTextTile component.
WOStudentTextTile

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- additionalButtons (a list of or a singular dash component, string or number; optional):
    Buttons to add to the button group.

- childComponent (a list of or a singular dash component, string or number; optional):
    Component to use for within the card body.

- className (string; default ''):
    Classes for the outer most div.

- currentOptionHash (string; optional):
    Hash of the current options, used to determine if we should be in
    a loading state or not.

- currentStudentHash (string; optional):
    Hash of the current student, used to determine if we should be in
    a loading state or not.

- profile (dict; optional):
    The profile of the student.

- showName (boolean; default True):
    Determine whether the header with the student name should be
    visible or not.

- style (dict; optional):
    Style to apply to the outer most item. This is usually used to set
    the size of the tile."""
    _children_props = ['childComponent', 'additionalButtons']
    _base_nodes = ['childComponent', 'additionalButtons', 'children']
    _namespace = 'lo_dash_react_components'
    _type = 'WOStudentTextTile'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, style=Component.UNDEFINED, showName=Component.UNDEFINED, currentOptionHash=Component.UNDEFINED, currentStudentHash=Component.UNDEFINED, childComponent=Component.UNDEFINED, additionalButtons=Component.UNDEFINED, profile=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'additionalButtons', 'childComponent', 'className', 'currentOptionHash', 'currentStudentHash', 'profile', 'showName', 'style']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'additionalButtons', 'childComponent', 'className', 'currentOptionHash', 'currentStudentHash', 'profile', 'showName', 'style']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(WOStudentTextTile, self).__init__(**args)

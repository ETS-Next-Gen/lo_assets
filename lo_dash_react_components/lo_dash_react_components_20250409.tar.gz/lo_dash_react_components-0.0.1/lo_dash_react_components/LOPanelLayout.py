# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class LOPanelLayout(Component):
    """A LOPanelLayout component.
LOPanelLayout provides the image and name pair for a given profile

Keyword arguments:

- children (a list of or a singular dash component, string or number; optional):
    The children of the main window.

- id (string; default ""):
    The ID used to identify this component in Dash callbacks.

- className (string; default ""):
    Classes for the outer most div.

- panels (list of dicts; optional):
    The panels to be included in the display.

    `panels` is a list of dicts with keys:

    - children (a list of or a singular dash component, string or number; optional)

    - width (string; optional)

    - offset (number; optional)

    - side (string; optional)

    - className (string; optional)

    - id (string; required)

- shown (list of strings; optional):
    Which panels (by id) are currently being shown."""
    _children_props = ['panels[].children']
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'LOPanelLayout'
    @_explicitize_args
    def __init__(self, children=None, id=Component.UNDEFINED, className=Component.UNDEFINED, panels=Component.UNDEFINED, shown=Component.UNDEFINED, **kwargs):
        self._prop_names = ['children', 'id', 'className', 'panels', 'shown']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['children', 'id', 'className', 'panels', 'shown']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args if k != 'children'}

        super(LOPanelLayout, self).__init__(children=children, **args)

# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class WOSettings(Component):
    """A WOSettings component.


Keyword arguments:

- id (string; default ''):
    The ID used to identify this component in Dash callbacks.

- className (string; default ''):
    Classes for the outer most div.

- options (list of dicts; optional):
    Array of available options.

    `options` is a list of dicts with keys:

    - id (string; optional)

    - label (string; optional)

    - parent (string; optional)

    - types (dict; optional)"""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'WOSettings'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, options=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'options']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'options']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(WOSettings, self).__init__(**args)

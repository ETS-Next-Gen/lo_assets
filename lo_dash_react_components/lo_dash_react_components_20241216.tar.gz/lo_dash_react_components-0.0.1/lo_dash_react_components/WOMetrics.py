# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class WOMetrics(Component):
    """A WOMetrics component.
WOMetrics creates badges for numeric values.
It takes a property, `data`, and
outputs each item as a badge.
If the id of the item is not in the property `shown`,
it will not appear.

Keyword arguments:

- id (string; optional):
    The ID used to identify this component in Dash callbacks.

- className (string; optional):
    Classes for the outer most div.

- data (dict; optional):
    Data for the metrics should be in form: `{
    \"sentences\": {                 \"id\": \"sentences\",
    \"value\": 33,                 \"label\": \" sentences\"
    },         }`.

- shown (list; optional):
    Which ids to show."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'WOMetrics'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, data=Component.UNDEFINED, shown=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'data', 'shown']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'data', 'shown']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(WOMetrics, self).__init__(**args)

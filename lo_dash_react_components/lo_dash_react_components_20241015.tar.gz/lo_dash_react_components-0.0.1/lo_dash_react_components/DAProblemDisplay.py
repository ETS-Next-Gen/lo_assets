# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class DAProblemDisplay(Component):
    """A DAProblemDisplay component.
The DAProblemDisplay component is responsible for displaying
information about students, problems, and scaffolds. It takes in an
array of student objects, each containing their initials, the
problem they are working on, the scaffold they are using (if any),
and their unique ID.

It renders which scaffolds associate with which problems, and which
scaffolds or problems students are currently using.

Keyword arguments:

- problems (list of dicts; required):
    problems (array): An array of objects containing information about
    each problem: - title (string): The title of the problem. -
    description (string): A description of the problem. - id (string):
    The unique ID of the problem. - relatedScaffolds (array): An array
    of strings representing the IDs of scaffolds related to the
    problem.

    `problems` is a list of dicts with keys:

    - description (string; required)

    - id (string; required)

    - relatedScaffolds (list of strings; required)

    - title (string; required)

- scaffolds (list of dicts; required):
    scaffolds (array): An array of objects containing information
    about each scaffold: - id (string): The unique ID of the scaffold.
    - title (string): The title of the scaffold. - description
    (string): A description of the scaffold. - content (string): The
    content of the scaffold.

    `scaffolds` is a list of dicts with keys:

    - description (string; required)

    - id (string; required)

    - title (string; required)

- students (list of dicts; required):
    students (array): An array of objects containing information about
    each student: - initials (string): The student's initials. -
    problem (string): The ID of the problem the student is working on.
    - scaffold (string): The ID of the scaffold the student is using
    (if any). - id (string): The unique ID of the student.

    `students` is a list of dicts with keys:

    - id (string; required)

    - initials (string; required)

    - problem (string; required)

    - scaffold (string; optional)"""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'DAProblemDisplay'
    @_explicitize_args
    def __init__(self, students=Component.REQUIRED, problems=Component.REQUIRED, scaffolds=Component.REQUIRED, **kwargs):
        self._prop_names = ['problems', 'scaffolds', 'students']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['problems', 'scaffolds', 'students']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['problems', 'scaffolds', 'students']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(DAProblemDisplay, self).__init__(**args)

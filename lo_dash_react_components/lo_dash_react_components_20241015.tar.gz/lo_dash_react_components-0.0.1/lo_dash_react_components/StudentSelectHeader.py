# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class StudentSelectHeader(Component):
    """A StudentSelectHeader component.
Displays a header menu for selecting students

Keyword arguments:

- id (string; optional):
    A unique identifier for the component, used to identify it in Dash
    callbacks.

- className (string; optional):
    A string of class names to be added to the outermost div.

- selectedStudent (string; default ""):
    The currently selected student name.

- students (list of strings; optional):
    An array of student names to be displayed in the dropdown."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'StudentSelectHeader'
    @_explicitize_args
    def __init__(self, id=Component.UNDEFINED, className=Component.UNDEFINED, students=Component.UNDEFINED, selectedStudent=Component.UNDEFINED, **kwargs):
        self._prop_names = ['id', 'className', 'selectedStudent', 'students']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['id', 'className', 'selectedStudent', 'students']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        super(StudentSelectHeader, self).__init__(**args)

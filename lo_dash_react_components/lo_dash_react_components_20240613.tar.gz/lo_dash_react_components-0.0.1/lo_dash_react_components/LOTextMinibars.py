# AUTO GENERATED FILE - DO NOT EDIT

from dash.development.base_component import Component, _explicitize_args


class LOTextMinibars(Component):
    """A LOTextMinibars component.
A component that renders a miniature bar graph representation of text, where each bar represents a sentence, and each
set of bars, a paragraph

Keyword arguments:

- className (string; optional):
    Optional: A class to attach to the main div of the chart.

- height (number; optional):
    Optional: The height of the chart.

- text (string; required):
    The text from which the chart is generated.

- width (number; optional):
    Optional: The height of the chart.

- xmax (number; optional):
    Optional: The maximum value of x-axis on the chart (e.g. number of
    sentences + paragraph breaks). Leave blank to autorange.

- ymax (number; optional):
    Optional: The maximum value of y-axis on the chart (e.g. maximum
    sentence length). Leave blank to autorange."""
    _children_props = []
    _base_nodes = ['children']
    _namespace = 'lo_dash_react_components'
    _type = 'LOTextMinibars'
    @_explicitize_args
    def __init__(self, text=Component.REQUIRED, className=Component.UNDEFINED, height=Component.UNDEFINED, width=Component.UNDEFINED, xmax=Component.UNDEFINED, ymax=Component.UNDEFINED, **kwargs):
        self._prop_names = ['className', 'height', 'text', 'width', 'xmax', 'ymax']
        self._valid_wildcard_attributes =            []
        self.available_properties = ['className', 'height', 'text', 'width', 'xmax', 'ymax']
        self.available_wildcard_properties =            []
        _explicit_args = kwargs.pop('_explicit_args')
        _locals = locals()
        _locals.update(kwargs)  # For wildcard attrs and excess named props
        args = {k: _locals[k] for k in _explicit_args}

        for k in ['text']:
            if k not in args:
                raise TypeError(
                    'Required argument `' + k + '` was not specified.')

        super(LOTextMinibars, self).__init__(**args)
